import React from "react";
import TextInput from "./TextInput";

function UserForm(){

    function handleSubmit(e){
        // console.log("Name:",name);
        // console.log("email:",email);
    }
    
    return(
        <div>
            <TextInput label="name" />
            <TextInput label="email" />
            <button onClick={handleSubmit}>Submit</button>
        </div>
    );
}
export default UserForm;