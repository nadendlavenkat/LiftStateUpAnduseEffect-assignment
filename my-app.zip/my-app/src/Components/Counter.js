import { useState,useEffect } from "react"


function Counter(){

    const[count,setCount] = useState(10);
    const[name,setName] = useState("");
    useEffect(()=>{
      console.log("component is mounted with empty useEffect");
      return() =>{
        console.log("component is unmounted with empty ");
      }
    },[])

    useEffect(()=>{
      console.log(`component is mounted with only Count,  ${count}`);
      return() =>{
        console.log(`component is unmounted with only Count, ${count}`);
      }
    },[count])

    useEffect(()=>{
      console.log(`component is mounted with only name, ${name}`);
      return() =>{
        console.log(`component is unmounted with only name,  ${name}`);
      }
    },[name])

    useEffect(()=>{
      console.log(`component is mounted with name and Count ${count},${name}`);
      
      return() =>{
        console.log(`component is unmounted  with name and Count ${count}, ${name}`);
       
      }
    },[count,name])

    function incrementCount(){
        setCount(count + 1);
    }
    function updateName(){
     
      setName("Venkat");
  }

    return (
      <>
        <h1>Counter: {count}</h1>
        <button onClick={incrementCount}>incrementCount</button>
        <h1>Counter: {name}</h1>
        <button onClick={updateName}>updateName</button>
      </>   
    )
}

export default Counter;