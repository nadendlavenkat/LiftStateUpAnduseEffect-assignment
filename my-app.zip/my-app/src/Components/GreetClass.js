import React, { Component } from "react";

class GreetClass extends Component{
    constructor(props) {
        super(props);
      }
    render(){
        const {firstName, lastName,data} = this.props;
        const {address,salary} = data;
        return(
            <div>
                    <h1>class {firstName} and {lastName}</h1>                     
                    <h1>class  salary: {salary} and city:{address.city}</h1>                 
            </div>
        );
    }
}
export default GreetClass;