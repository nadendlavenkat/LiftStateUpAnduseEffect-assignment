import React, { Component, useEffect, useState } from "react";


function PostList(){
    //  function loginUser(credentials) {
    //     var resp;
    //     return fetch("http://127.0.0.1:8000/api/token-auth/", {
    //       method: "POST",
    //       headers: {
    //         "Content-Type": "application/json"
    //       },
    //       body: JSON.stringify(credentials)
    //     }).then(response => {
    //       resp = response;
    //       return response.json();
    //     }).then(json => {
    //       return {
    //         response: resp,
    //         json: json,
    //         error: !resp.ok
    //       };
    //     });
    //   }
    const[posts,setPosts]= useState([]);
    //const[albums,setAlbums]= useState([]);
    const[error,setError]= useState('');
    const[loading,setLoading]= useState(true);
    useEffect(()=>{
       
        // fetch('https://jsonplaceholder.typicode.com/posts')
        // .then(response => {
        //     if(response.ok){
        //         return response.json();
        //     }
        //     else{
        //         throw new Error(response.status);
        //     }
        // })
        // .then(data => {           
        //         setLoading(false);
        //         setPosts(data);
        // })
        // .catch(error =>{
        //     setLoading(false);
        //     setError("Something went wrong");
        //     console.log(error);
        // })

        const fetchData = async () =>{
            try{
                const response = await fetch('https://jsonplaceholder.typicode.com/posts');
                if(!response.ok){
                    throw new Error(response.status);
                }
                const data= await response.json();
                setPosts(data);
                setLoading(false);
            }
            catch(error){
                setError(error.message);
                setLoading(false);
            }
        }
        fetchData();

    },[]);
    if(error){
        return <div>error: {error}</div>
    }
    if(loading){
        return <div>loading...</div>
    }
    return(
        <div>
            List of Posts
            <ul>
                {
                    posts.map(post => <li key={post.id}>{post.title}</li>)
                }
            </ul>
        </div>
    )

}
export default PostList;