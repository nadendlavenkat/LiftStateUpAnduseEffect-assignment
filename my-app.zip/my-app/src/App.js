import logo from './logo.svg';
import './App.css';
import PostList from './Components/PostList';
import PostListAxios from './Components/FetchAPI/PostListAxios';
import MyComponent from './Components/FetchAPI/MyComponent';
import UserForm from './Components/WithoutLiftState/UserForm';
import UserFormLS from './Components/WithLiftStateUp/UserFormLs';
import Counter from './Components/Counter';


function App() {
  return (
    <div className="App">
      {/* <UseFormLS /> */}
      {/* for useEffect */}
      <Counter />
      {/* <UseForm /> */}
      {/* <MyComponent /> */}

      {/* <PostListAxios />
      <PostList /> */}
    </div>
  );
}

export default App;
