//Hook is a special function that lets you 'hook into' React features
//useState is a Hook that lets you add React state to function components
import React, { useState } from "react"; 

function NumberState()
{
   // Declared a usestate variable, called "number" and initialized with zero
   // When we declare a state variable with useState, it returns a pair — an array with two items.
   // The first item is the current value, and the second is a function that lets us update it
    const[number,setNumber] = useState(0);

    //incrementing the number with 1 whenever we hit incrementNumber method
    function incrementNumber()
    {
        setNumber(number + 1);
    }

    //decrementing the number with 1 whenever we hit decrementNumber method
    function decrementNumber()
    {     
        setNumber(number - 1);
    }

    //restting the number with zero whenever we hit resetNumber method
    function resetNumber()
    {     
        setNumber(0);
    }

    //defined a button for the IncrementNumber
    function IncrementNumberButton() {
        return (
            <button onClick={incrementNumber}>Increment Number</button>  
        );
    }

    //defined a button for the DecrementNumber
    function DecrementNumberButton() {
        return (
            <button style={{marginLeft:5}} onClick={decrementNumber}>Decrement Number</button>
        );
    }

     //defined a button to ResetNumber
    function ResetNumberButton() {
        return (
            <button style={{marginLeft:5}} onClick={resetNumber}>Reset Number</button>
        );
    }
   
    return (
        <>
            <h1>Assignment: React useState Hook Assignment using NumberState.js</h1>
            <div>
                <h3>Task 1: Create the `NumberState` Component</h3>
                <h3>Task 2: Implement State with `useState`</h3>
                <h3>Task 3: Enable State Manipulation</h3>
            </div>
            <div>
                <h1>Number: {number}</h1>
                <IncrementNumberButton />
                <DecrementNumberButton />
                <ResetNumberButton />
            </div>
        </>
    );
    
}

export default NumberState;