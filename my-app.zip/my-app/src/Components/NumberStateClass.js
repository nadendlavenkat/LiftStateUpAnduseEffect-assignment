//Hook is a special function that lets you 'hook into' React features
//useState is a Hook that lets you add React state to function components
import React,{ Component } from "react";

class NumberStateClass extends Component
{
    constructor(props){      
        super(props);
        this.state = {
            count: 0
        };
        console.log("constructor");
    }
   // Declared a usestate variable, called "number" and initialized with zero
   // When we declare a state variable with useState, it returns a pair — an array with two items.
   // The first item is the current value, and the second is a function that lets us update it
  

    //incrementing the number with 1 whenever we hit incrementNumber method
    incrementNumber = () => {
        debugger;
        this.setState(prevState => ({
            count: prevState.count + 1,
        }));
    }
   

    //decrementing the number with 1 whenever we hit decrementNumber method
    decrementNumber = () => {
        debugger;
        this.setState(prevState => ({
           count: prevState.count - 1,
        }));
    }
    //restting the number with zero whenever we hit resetNumber method
    resetNumber = () => {
        debugger;
        this.setState(currentState => ({
            count: 0
         }));
    }
    render(){
        return (
            <div>                
                <h1>Assignment: React useState Hook Assignment using NumberStateClass</h1>
                <h3>Task 1: Create the `NumberState` Component </h3>
                <h3>Task 2: Implement State with `useState`</h3>
                <h3>Task 3: Enable State Manipulation</h3>
                <h1>count: {this.state.count}</h1>
                <button onClick={this.incrementNumber}>Increment Number</button>
                <button style={{marginLeft:5}} onClick={this.decrementNumber}>Decrement Number</button>
                <button style={{marginLeft:5}} onClick={this.resetNumber}>Reset Number</button>
            </div>
        )
    }    
}

export default NumberStateClass;