import React from "react";

function FetchData(){
    try{
        
    }
    catch(error){

    }
}
export default FetchData;