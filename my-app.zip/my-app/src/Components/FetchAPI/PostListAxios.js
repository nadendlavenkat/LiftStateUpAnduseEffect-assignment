import React, { useEffect, useState } from "react";
import axios from "axios";

function PostListAxios(){
   
    const[posts,setPosts]= useState([]);   
    const[loading,setLoading]= useState(true);
    const[error,setError]= useState('');
    
    useEffect(()=>{

        const fetchData = async () =>{
            try{
                const response = await axios.get("https://jsonplaceholder.typicode.com/posts");
                const data = await response.data;
                setLoading(false);
                setPosts(data);               
            }
            catch(error){
                setError(error.message);
                setLoading(false);
            }
        }
        //fetchData();


        const fetchDataUsingThenAndCatch = async () =>{
            try{
                const response = await axios.get("https://jsonplaceholder.typicode.com/posts")
                .then(response =>{
                    setPosts(response.data); 
                    setLoading(false);    
                })
                .catch(error =>{
                    setError(error.message);
                    setLoading(false);
                });         
            }
            catch(error){
                setError(error.message);
                setLoading(false);
            }
        }
        fetchDataUsingThenAndCatch();
    },[]);

    if(error){
        return <div>error: {error}</div>
    }
    if(loading){
        return <div>loading...</div>
    }

    return(
        <div>
            List of Posts using axios 
            <ul>
                {
                    posts.map(post => <li key={post.id}>{post.title}</li>)
                }
            </ul>
        </div>
    )

}
export default PostListAxios;