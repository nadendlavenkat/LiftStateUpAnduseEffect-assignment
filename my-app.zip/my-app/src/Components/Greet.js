import React, { useState } from 'react';


// let content = false;
// let isLoggedIn;
// if (content) {
//     isLoggedIn = true;
// } else {
//     isLoggedIn =false;
// }

function Greet(props)
{   
  const {firstName, lastName,data} = props;
  const {address,salary} = data;
    return (
        <div>
                <h1>hello welcome to the fist component {props.firstName} and {props.lastName}</h1>  
                <h1>using data destructuring concept {firstName} and {lastName}</h1> 
                <h1>using object  salary: {salary} and city:{address.city}</h1> 
                <MyButton />     
                <Profile />
        </div>
    )
}

function MyButton() {
    const [count, setCount] = useState(0);
    function handleClick() {
        setCount(count + 1);
        alert(`Clicked ${count} times`);
      }

    return (
      <button onClick={handleClick}>
        I'm a button
      </button>
    );
  }
  function Profile() {
    return (
      <>
        <h1>{user.name}</h1>
        <img
          className="avatar"
          src={user.imageUrl}
          alt={'Photo of ' + user.name}
          style={{
            width: user.imageSize,
            height: user.imageSize
          }}
        />
      </>
    );
  }
  const user = {
    name: 'Hedy Lamarr',
    imageUrl: 'https://i.imgur.com/yXOvdOSs.jpg',
    imageSize: 90,
  };

export default Greet;